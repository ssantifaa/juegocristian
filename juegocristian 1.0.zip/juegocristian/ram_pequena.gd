extends ProgressBar


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	self.get_node("Label").text = str(0) + " / " + str(Global.RAM_PEQUENA_MAX) + " MB"
	Global.RAMPequena = self
