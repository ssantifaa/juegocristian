extends ProgressBar


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	self.get_node("Label").text = str(0) + " / " + str(Global.RAM_GRANDE_MAX) + " MB"
	Global.RAMGrande = self
