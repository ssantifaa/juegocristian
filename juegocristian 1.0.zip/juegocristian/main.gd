
extends Node2D



func _ready() -> void:
	Global.iniciar_jornada()
