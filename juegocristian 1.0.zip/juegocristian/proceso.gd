extends Area2D

var memoria := 0
var cpu := 0
var tiempo := 0.0
var velocidad := 250.0
var ejecutando := false
var particion_actual := ""
var electo = null
@onready var color_rect = $ColorRect


var colores = [
	Color("#00A8F3"),
	Color("#00C853"),
	Color("#FFB300"),
	Color("#E53935"),
	Color("#AB47BC"),
	Color("#F4511E")
]


@onready var etiqueta = $Label
@onready var etiqueta2 = $Label2

func _ready() -> void:
	add_to_group("procesos")
	memoria = randi_range(4, 32)
	cpu = randi_range(5, 20)
	tiempo = randf_range(5.0, 15.0)

	color_rect.color = colores.pick_random()
	etiqueta.text = str(memoria) + " MB"
	etiqueta2.text = str(cpu) + "% CPU"
	


func _process(delta: float) -> void:
	if Global.esta_comprimiendo:
		return
	
	position.x += velocidad * delta

func particion_pequena() -> bool:
	if Global.agregar_ram_pequena(memoria):
		print("PROCESO: entré en partición pequeña")
		ejecutando = true
		particion_actual = "pequena"
		Global.ultimo_proceso_ejecutado = self
		Global.llenar_particion_pequena(memoria)
		Global.llenar_cpu(cpu)
		return true
	
	print("PROCESO: NO ENTRÉ EN PARTICIÓN PEQUEÑA")
	Global.llenar_cpu(cpu / 4)
	return false

func particion_grande() -> bool:
	if Global.agregar_ram_grande(memoria):
		print("PROCESO: entré en partición grande")
		ejecutando = true
		particion_actual = "grande"
		Global.ultimo_proceso_ejecutado = self
		Global.llenar_particion_grande(memoria)
		Global.llenar_cpu(cpu)
		return true
	
	print("PROCESO: NO ENTRÉ EN PARTICIÓN GRANDE")
	Global.llenar_cpu(cpu / 4)
	return false

func swap() -> void:
	if not ejecutando:
		return
	
	# Liberamos la memoria de la RAM en el Global directamente
	Global.swapear_proceso(devolver_memoria(), particion_actual)
	ejecutando = false
	particion_actual = "swap"
	print("PROCESO: fui swapeado")

func comprimir() -> void:
	print("PROCESO: fui comprimido")
	Global.comprimir()
func devolver_memoria() -> int:
	return memoria

func devolver_cpu() -> int:
	return cpu

func terminar_proceso() -> void:
	ejecutando = false

	if particion_actual == "pequena":
		Global.liberar_ram_pequena(memoria)

	elif particion_actual == "grande":
		Global.liberar_ram_grande(memoria)

	print("PROCESO: terminé")
	Global.liberar_cpu(devolver_cpu())
	queue_free()

func _on_timer_timeout() -> void:
	if not ejecutando:
		return
	if Global.esta_comprimiendo: return

	tiempo -= 0.1

	if tiempo <= 0:
		terminar_proceso()
