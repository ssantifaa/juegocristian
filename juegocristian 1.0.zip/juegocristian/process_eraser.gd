extends Area2D

func _on_area_entered(area: Area2D) -> void:
	if area.is_in_group("procesos"):
		print("Se eliminó por fin el nodo restante")
		area.queue_free()
