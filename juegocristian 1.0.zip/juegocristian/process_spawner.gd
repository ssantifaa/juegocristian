
extends Node2D

@export var proceso_scene: PackedScene

var intervalo := 1



func _ready() -> void:
	
	match Global.nivel:
		1:
			intervalo = 1.5
		2:
			intervalo = 1
		3:
			intervalo = 0.75
	$spawn_timer.wait_time = intervalo
	$spawn_timer.start()
	
func _on_spawn_timer_timeout() -> void:
	var proceso = proceso_scene.instantiate()

	add_child(proceso)

	proceso.position = $spawn_point.position
	
	
