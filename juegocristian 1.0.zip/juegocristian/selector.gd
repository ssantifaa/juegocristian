extends Area2D

var proceso_actual = null
@onready var kernel := $"../kernel"
var elegido = false

func _ready() -> void:
	print("SELECTOR: estoy vivo")
	kernel.particion_pequena.connect(_enviar_particion_pequena)
	kernel.particion_grande.connect(_enviar_particion_grande)
	kernel.swap.connect(_swapear)
	kernel.comprimir.connect(_comprimir)

func _on_area_entered(area: Area2D) -> void:
	if area.is_in_group("procesos"):
		elegido = false
		proceso_actual = area
		print("SELECTOR: proceso entró")
		proceso_actual.electo = elegido
		

func _on_area_exited(area: Area2D) -> void:
	if area == proceso_actual:
		proceso_actual = null
		print("SELECTOR: PROCESO SALIO")

func _enviar_particion_pequena() -> void:
	if Global.esta_comprimiendo:
		return

	if elegido:
		return

	if proceso_actual == null:
		return
	
	if proceso_actual.particion_pequena():
		elegido = true
		proceso_actual.electo = elegido

func _enviar_particion_grande() -> void:
	if Global.esta_comprimiendo:
		return

	if elegido:
		return

	if proceso_actual == null:
		return
	
	if proceso_actual.particion_grande():
		elegido = true
		proceso_actual.electo = elegido

func _swapear() -> void:
	if Global.swapear_ultimo_proceso():
		print("SELECTOR: Espacio liberado en RAM mediante SWAP")
	else:
		print("SELECTOR: No se pudo swapear nada")
	
	print("SELECTOR: proceso swapeado")
	
	
func _comprimir() -> void:
	if Global.esta_comprimiendo:
		return
	
	if proceso_actual == null:
		print("SELECTOR: no hay proceso seleccionado")
		return
	
	print("SELECTOR: proceso comprimido")
	proceso_actual.comprimir()
	elegido = true
	proceso_actual.electo = elegido
