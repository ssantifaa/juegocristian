extends ProgressBar


func _ready() -> void:
	Global.CPU = self

	
func _process(delta: float) -> void:
	self.value -= 0.01
