extends Control


func _on_restart_pressed() -> void:
	Global.reiniciar_juego()
	get_tree().change_scene_to_file("res://main.tscn")


func _on_menu_pressed() -> void:
	get_tree().change_scene_to_file("res://main_menu.tscn")
