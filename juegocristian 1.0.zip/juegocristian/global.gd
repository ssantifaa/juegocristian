extends Node

var nivel := 1


const RAM_PEQUENA_MAX := 32
const RAM_GRANDE_MAX := 92
const SWAP_CPU :=10

var ram_pequena := 0
var ram_grande := 0
var RAMPequena : ProgressBar = null
var RAMGrande : ProgressBar = null
var CPU : ProgressBar = null
var esta_comprimiendo := false
var juego_perdido := false
var tiempo_cpu_extrema := 0.0

var ultimo_proceso_ejecutado: Area2D = null

var procesos_restantes := 0

signal nivel_ganado

func iniciar_jornada() -> void:
	procesos_restantes = 10 + (nivel - 1) * 5
	print("GLOBAL: Jornada iniciada. Procesos totales: ", procesos_restantes)

func descontar_proceso() -> void:
	procesos_restantes -= 1
	print("GLOBAL: Procesos restantes en la jornada: ", procesos_restantes)
	
	if procesos_restantes <= 0:
		ganar_jornada()

func ganar_jornada() -> void:
	print("GLOBAL: ¡Sobreviviste a la jornada!")
	nivel += 1
	get_tree().call_deferred("res://cartel_victoria.tscn") 

func agregar_ram_pequena(cantidad: int) -> bool:
	if ram_pequena + cantidad > RAM_PEQUENA_MAX:
		return false
	
	ram_pequena += cantidad
	return true

func agregar_ram_grande(cantidad: int) -> bool:
	if ram_grande + cantidad > RAM_GRANDE_MAX:
		return false
	
	ram_grande += cantidad
	return true
	
func llenar_particion_pequena(cantidad: int) -> void:
	RAMPequena.value += cantidad
	RAMPequena.get_node("Label").text = str(RAMPequena.value) + " / " + str(RAM_PEQUENA_MAX) + " MB"


func llenar_particion_grande(cantidad: int) -> void:
	RAMGrande.value += cantidad
	RAMGrande.get_node("Label").text = str(RAMGrande.value) + " / " + str(RAM_GRANDE_MAX) + " MB"

func liberar_ram_pequena(cantidad: int) -> void:
	ram_pequena -= cantidad
	RAMPequena.value -= cantidad
	RAMPequena.get_node("Label").text = str(RAMPequena.value) + " / " + str(RAM_PEQUENA_MAX) + " MB"

func liberar_ram_grande(cantidad: int) -> void:
	ram_grande -= cantidad
	RAMGrande.value -= cantidad
	RAMGrande.get_node("Label").text = str(RAMGrande.value) + " / " + str(RAM_GRANDE_MAX) + " MB"
	
func llenar_cpu(cpu: int) -> void:
		CPU.value += cpu

func liberar_cpu(cpu: int):
	CPU.value -= cpu

func swapear_proceso(cantidad: int, particion: String) -> void:
	if particion == "pequena":
		liberar_ram_pequena(cantidad)
	elif particion == "grande":
		liberar_ram_grande(cantidad)

	if CPU: CPU.value += SWAP_CPU

func swapear_ultimo_proceso() -> bool:
	if ultimo_proceso_ejecutado == null or not is_instance_valid(ultimo_proceso_ejecutado):
		print("GLOBAL: No hay procesos en RAM para hacer swap")
		return false
	
	if ultimo_proceso_ejecutado.ejecutando:
		var objetivo = ultimo_proceso_ejecutado
		ultimo_proceso_ejecutado = null # Limpiamos la referencia antes de invocar el método
		objetivo.swap()
		print("GLOBAL: Se swapeó exitosamente el último proceso cargado")
		return true
		
	return false

func comprimir() -> void:
	esta_comprimiendo = true
	await get_tree().create_timer(1.0).timeout
	esta_comprimiendo = false
	
	if not juego_perdido and is_instance_valid(CPU):
		CPU.value -= 10

func perder_juego() -> void:
	if juego_perdido:
		return
	
	juego_perdido = true
	get_tree().change_scene_to_file("res://game_over.tscn")

func _process(delta: float) -> void:
	if juego_perdido:
		return
	
	if CPU == null:
		return
	
	if CPU.value <= 0 or CPU.value >= 90:
		tiempo_cpu_extrema += delta
	else:
		tiempo_cpu_extrema = 0.0
	
	if tiempo_cpu_extrema >= 2.0:
		perder_juego()

func reiniciar_juego() -> void:
	juego_perdido = false
	tiempo_cpu_extrema = 0.0
	ram_pequena = 0
	ram_grande = 0
	esta_comprimiendo = false
