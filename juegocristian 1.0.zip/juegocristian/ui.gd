extends Control

@onready var kernel := $"../kernel"

@onready var anim_pequena := $LButton/AnimationPlayer
@onready var anim_grande := $RButton/AnimationPlayer
@onready var anim_swap := $Sbutton/AnimationPlayer
@onready var anim_comprimir := $Cbutton/AnimationPlayer


func _ready() -> void:
	kernel.particion_pequena.connect(_animar_pequena)
	kernel.particion_grande.connect(_animar_grande)
	kernel.swap.connect(_animar_swap)
	kernel.comprimir.connect(_animar_comprimir)


func _animar_pequena() -> void:
	anim_pequena.play("presionado")


func _animar_grande() -> void:
	anim_grande.play("presionado")


func _animar_swap() -> void:
	anim_swap.play("presionado")


func _animar_comprimir() -> void:
	anim_comprimir.play("presionado")
