extends Control





func _on_level_1_pressed() -> void:
	Global.nivel = 1
	get_tree().change_scene_to_file("res://main.tscn")

func _on_level_2_pressed() -> void:
	Global.nivel = 2
	get_tree().change_scene_to_file("res://main.tscn")


func _on_level_3_pressed() -> void:
	Global.nivel = 3
	get_tree().change_scene_to_file("res://main.tscn")
