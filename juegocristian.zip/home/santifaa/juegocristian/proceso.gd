extends Area2D

var memoria := 0
var cpu := 0
var tiempo := 0.0

func _ready() -> void:
	memoria = randi_range(4, 32)
	cpu = randi_range(5, 20)
	tiempo = randf_range(3.0, 10.0)
