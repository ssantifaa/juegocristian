extends Area2D

var memoria := 0
var cpu := 0
var tiempo := 0.0
var velocidad := 250.0

@onready var etiqueta = $Label


func _ready() -> void:
	memoria = randi_range(4, 32)
	cpu = randi_range(5, 20)
	tiempo = randf_range(3.0, 10.0)

	etiqueta.text = str(memoria) + " MB"


func _process(delta: float) -> void:
	position.x += velocidad * delta
