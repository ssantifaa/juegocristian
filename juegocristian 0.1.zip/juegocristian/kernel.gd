extends Node

signal particion_pequena
signal particion_grande
signal swap
signal comprimir

func _process(_delta):

	if Input.is_action_just_pressed("ui_left"):
		particion_pequena.emit()

	elif Input.is_action_just_pressed("ui_right"):
		particion_grande.emit()

	elif Input.is_action_just_pressed("ui_up"):
		swap.emit()

	elif Input.is_action_just_pressed("ui_down"):
		comprimir.emit()
